#include "procesos.h"
#include<stdio.h>
#include<stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/time.h>

void controlar_rafaga(int *lanzados_en_rafaga, int tamRafaga, int tiempoEntreRafagas) {
    if (tamRafaga <= 0) return;

    (*lanzados_en_rafaga)++;

    if (*lanzados_en_rafaga >= tamRafaga) {
        usleep(tiempoEntreRafagas);
        *lanzados_en_rafaga = 0;
    }
}

/**
 * Argv[2] es el modo de inicio apra distintos escenarios:
 * 1 - Escritor tras Lector v1 (sim3.txt)
 */
int main(int argc, char *argv[]){
    if(argc < 3){
        printf("ERROR. USO: %s [archivo] [modo_inicio]\n",argv[0]);
        return 1;
    }
    remove("salida.txt");
    char linea[100];
    char idNodo[12];
    int i,numNodos=0,numPagos=0,numAnulaciones=0,numReservas=0,numAdmin=0,numConsultas=0;
    int tiempoSC=0;
    int n =0;
    int a;
    int tamRafaga = 0;
    int tiempoEntreRafagas = 0; //En ms
    struct timeval timeInicio, timeFin;

    FILE *ficheroConfig = fopen(argv[1], "r");
    if (ficheroConfig == NULL) {
        printf("No se pudo abrir el archivo %s\n", argv[1]);
        return 1;
    }
    gettimeofday(&timeInicio, NULL);
    while (fgets(linea, sizeof linea, ficheroConfig) != NULL && linea[0] != '\n') {
        char *eq = strchr(linea, '=');

        if (eq == NULL) {
            printf("Línea inválida: %s", linea);
            continue;
        }

        *eq = '\0';

        char *variable = linea;
        int valor = atoi(eq + 1);

        if (strcmp(variable, "numNodos") == 0) {
            numNodos = valor;
            printf("numNodos: %d\n", numNodos);
        } else if (strcmp(variable, "numPagos") == 0) {
            numPagos = valor;
            printf("numPagos: %d\n", numPagos);
        } else if (strcmp(variable, "numAnulaciones") == 0) {
            numAnulaciones = valor;
            printf("numAnulaciones: %d\n", numAnulaciones);
        } else if (strcmp(variable, "numReservas") == 0) {
            numReservas = valor;
            printf("numReservas: %d\n", numReservas);
        } else if (strcmp(variable, "numAdmin") == 0) {
            numAdmin = valor;
            printf("numAdmin: %d\n", numAdmin);
        } else if (strcmp(variable, "numConsultas") == 0) {
            numConsultas = valor;
            printf("numConsultas: %d\n", numConsultas);
        } else if (strcmp(variable, "tiempoSC") == 0) {
            tiempoSC = valor;
            printf("tiempoSC: %d\n", tiempoSC);
        } else if (strcmp(variable, "tamRafaga") == 0) {
            tamRafaga = valor;
            printf("tamRafaga: %d\n", tamRafaga);
        } else if (strcmp(variable, "tiempoEntreRafagas") == 0) {
            tiempoEntreRafagas = valor;
            printf("tiempoEntreRafagas: %d\n", tiempoEntreRafagas);
        } else {
            printf("Variable desconocida: %s\n", variable);
        }
    }
    if(numNodos <= 0 || numNodos > NUM_MAX_NODOS){
        printf("Número de nodos inválido. Debe ser entre 1 y %d.\n", NUM_MAX_NODOS);
        return 1;
    }
    if(tiempoSC <= 0){
        printf("Tiempo de sección crítica inválido. Debe ser un número positivo.\n");
        return 1;
    }
    if(numPagos < 0 || numAnulaciones < 0 || numReservas < 0 || numAdmin < 0 || numConsultas < 0){
        printf("Número de operaciones inválido. No puede ser negativo.\n");
        return 1;
    }
    if(tamRafaga < 0){
        printf("Tamaño de ráfaga inválido. No puede ser negativo.\n");
        return 1;
    }
    if(tiempoEntreRafagas < 0){
        printf("Tiempo entre ráfagas inválido. No puede ser negativo.\n");
        return 1;
    }
    fclose(ficheroConfig);
    
    char tiempoSCStr[12];
    snprintf(tiempoSCStr, sizeof(tiempoSCStr), "%d", tiempoSC);
    char numNodosStr[12];
    snprintf(numNodosStr, sizeof(numNodosStr), "%d", numNodos);

    int procesosReceptor[numNodos+1];
    for(i=1; i<=numNodos; i++){
        procesosReceptor[i] = fork();
        if(procesosReceptor[i] == 0){
            //Aquí va el execl
            snprintf(idNodo, sizeof(idNodo), "%d", i);
            execl("./receptor", "receptor", idNodo, numNodosStr, tiempoSCStr, NULL);
            return 0;
        }
    }
    sleep(3);



    int numOperaciones = (numPagos + numAnulaciones + numReservas + numAdmin + numConsultas) * numNodos;
    int procesosHijos[numOperaciones+1];

    int lanzados_en_rafaga = 0;
    for(i=1; i<=numNodos;i++){
        snprintf(idNodo, sizeof(idNodo), "%d", i);

        for(a=0;a<numAnulaciones;a++){
            procesosHijos[n] = fork();
            if(procesosHijos[n] == 0){
                //Aquí va el execl
//                if(atoi(argv[2]) == 1) {
//                    usleep(100000);
//                    if(a == numAnulaciones/2) {
//                        execl("./pagos", "pagos", idNodo, NULL);
//                    }
//                }
                execl("./anulaciones", "anulaciones", idNodo, NULL);
            }
            n++;
            controlar_rafaga(&lanzados_en_rafaga, tamRafaga, tiempoEntreRafagas);
        }

        for(a=0;a<numPagos;a++){
            procesosHijos[n] = fork();
            if(procesosHijos[n] == 0){
                //Aquí va el execl
                execl("./pagos", "pagos", idNodo, NULL);
            }
            n++;
            controlar_rafaga(&lanzados_en_rafaga, tamRafaga, tiempoEntreRafagas);

        }
        
        for(a=0;a<numAdmin;a++){
            procesosHijos[n] = fork();
            if(procesosHijos[n] == 0){
                //Aquí va el execl
//                if(atoi(argv[2]) == 1) {
//                    usleep(100000);
//                    if(a == numAdmin/2) {
//                        execl("./pagos", "pagos", idNodo, NULL);
//                    }
//                }
                execl("./administraciones", "administraciones", idNodo, NULL);
            }
            n++;
            controlar_rafaga(&lanzados_en_rafaga, tamRafaga, tiempoEntreRafagas);
        }
        for(a=0;a<numReservas;a++){
            procesosHijos[n] = fork();
            if(procesosHijos[n] == 0){
                //Aquí va el execl
//                if(atoi(argv[2]) == 1) {
//                    usleep(1000000);
//                    if(a == numReservas/2) {
//                        execl("./pagos", "pagos", idNodo, NULL);
//                    }
//                }
                execl("./reservas", "reservas", idNodo, NULL);
            }
            n++;
            controlar_rafaga(&lanzados_en_rafaga, tamRafaga, tiempoEntreRafagas);
        }
        
        for(a=0;a<numConsultas;a++){
            procesosHijos[n] = fork();
            if(procesosHijos[n] == 0){
                //Aquí va el execl
//                if(atoi(argv[2]) == 1) {
//                    usleep(100000);
//                    if(a == numConsultas/2) {
//                        execl("./pagos", "pagos", idNodo, NULL);
//                    }
//                }
                execl("./consultas", "consultas", idNodo, NULL);
            }
            n++;
            controlar_rafaga(&lanzados_en_rafaga, tamRafaga, tiempoEntreRafagas);
        }
    }
    printf("SIMULACIÓN COMENZADA\n");
    for (i = 0; i < numOperaciones; i++) {
        waitpid(procesosHijos[i], NULL, 0);
    }
    gettimeofday(&timeFin, NULL);
    
    printf("SIMULACIÓN TERMINADA\n");

    long sec_tiempo_fin_sim = timeFin.tv_sec - timeInicio.tv_sec;
    long micros_tiempo_fin_sim = sec_tiempo_fin_sim*1000000 + timeFin.tv_usec - timeInicio.tv_usec;
    //fprintf(fopen("salida.txt", "a"), "%ld", micros_tiempo_fin_sim);
    
    return 0;
}